package DataAccessLayer;

import java.sql.Connection;

public interface DatabaseConnect {
    Connection connectDatabase();
}
