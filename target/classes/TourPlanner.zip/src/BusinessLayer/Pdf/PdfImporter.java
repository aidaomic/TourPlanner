package BusinessLayer.Pdf;

public interface PdfImporter {
    void importFromPdf();
}
