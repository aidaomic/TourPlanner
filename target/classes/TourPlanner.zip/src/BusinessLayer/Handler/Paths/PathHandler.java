package BusinessLayer.Handler.Paths;

public interface PathHandler {
    String inputPath();
    String viewPath(String methode);
}
