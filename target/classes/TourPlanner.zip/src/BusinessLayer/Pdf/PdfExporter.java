package BusinessLayer.Pdf;

public interface PdfExporter {
    void toPdfTable();
    void toPdf();
}
