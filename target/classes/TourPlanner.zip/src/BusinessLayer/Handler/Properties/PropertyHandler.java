package BusinessLayer.Handler.Properties;

public interface PropertyHandler {
    void setUpPropertyHandler();
}
