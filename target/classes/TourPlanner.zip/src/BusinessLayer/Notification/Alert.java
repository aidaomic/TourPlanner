package BusinessLayer.Notification;

public interface Alert {
    void setUpAlert();
}
